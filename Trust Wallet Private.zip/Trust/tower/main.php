<?php

include_once 'defender.php';
require_once 'detect.php';
?>